# Tik Conector — Entregas

- [x] **Identidade e entrada do produto** — O site deve se chamar Tik Conector; usar tema de cores inspirado no TikTok; apresentar telas bonitas e profissionais de login e registro; ser otimizado para celular.
- [x] **Persistência sem banco** — Não usar banco de dados; armazenar a demonstração em um documento JSON local seguro para a prévia, com sessão e perfil persistidos no navegador.
- [x] **Dashboard creator** — Permitir conectar o TikTok via username, exibir estado de live, métricas, atividade recente e acesso aos jogos.
- [x] **Cinco jogos jogáveis** — Criar Batalha de Likes, Chuva de Gifts, Duelo de Comentários, Corrida de Seguidores e Caça ao Viral, cada um com regras, feedback e estado jogável.
- [x] **Assets dos jogos** — Criar cerca de 10 assets de imagem para cada jogo, mantendo estilo visual consistente e usando-os dentro das experiências.
- [x] **Monitoramento e orientação** — Ao entrar em um jogo, pedir username do TikTok, iniciar monitoramento simulado em tempo real na prévia, mostrar eventos e oferecer tela cheia com layout horizontal.
- [x] **Perfil** — Criar aba de perfil com avatar, username, bio, estatísticas, preferências e logout.
- [x] **Entrega** — Disponibilizar Preview funcional, com manifesto de rotas e projeto inicializado no Webdev.
