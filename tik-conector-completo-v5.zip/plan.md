# Tik Conector — Plano de implementação

## Escopo aprovado
Criar um web app mobile-first chamado Tik Conector, com identidade visual inspirada no TikTok, entrada por login/registro local, dashboard, perfil, conexão por username do TikTok e cinco jogos interativos jogáveis. Cada jogo terá um fluxo para informar o username, iniciar uma sessão de live simulada em tempo real na prévia e abrir o gameplay em modo horizontal/tela cheia. A persistência da demonstração será feita em JSON no `localStorage`, sem banco de dados.

## Decisões técnicas
- Stack: HTML, CSS e JavaScript modular servido por Vite, sem dependência de banco.
- Persistência: um documento JSON versionado em `localStorage` com usuários, sessão, perfil, últimos jogos e configurações; senhas serão armazenadas apenas como hash local de demonstração, com aviso de que produção deve usar backend seguro.
- Integração TikTok: adaptador `tiktokLiveConnector` isolado em módulo, com mock de eventos para a prévia. A interface exibirá claramente “modo demonstração” e ficará pronta para substituir o mock pelo SDK/serviço oficial.
- Rotas: SPA com estados `/`, `/login`, `/register`, `/app`, `/profile` e `/game/:id`; manifesto em `public/manus-routes.json`.
- Assets: arte visual própria com glow ciano/rosa, entregues em `public/assets/`. Cinco packs com 10 imagens cada, além de marca e imagem de capa.

## Direção visual
Três possibilidades consideradas:
1. Neon editorial mobile-first — 0,07
2. Arcade cyber-pop — 0,05
3. Minimalismo creator-tech — 0,08

### Escolha: Neon editorial mobile-first

- **Movimento:** interfaces creator-tech inspiradas em overlays de live, com editorialidade escura e acentos neon.
- **Princípios:** alto contraste, leitura em uma mão, feedback em tempo real e sensação premium sem excesso de ruído.
- **Cores:** fundo quase preto azulado; ciano e magenta como energia e interação; branco suave para conteúdo; verde limão para estados de conexão e sucesso.
- **Layout:** shell assimétrico com navegação inferior fixa no mobile, hero com painel de status e seções horizontais roláveis em vez de uma grade rígida.
- **Assinaturas:** wordmark com símbolo de conexão dupla, linhas de transmissão tracejadas e cards com borda “scanline” suave.
- **Interação:** toda ação importante responde com microanimação, toast ou mudança de estado visível; botões têm verbos claros.
- **Animação:** pulso lento para LIVE, barras de atividade em loop, entrada por fade/slide curto e confete reservado para eventos de jogo.
- **Tipografia:** `Space Grotesk` para títulos, `DM Sans` para interface e `JetBrains Mono` para dados e eventos.
- **Essência:** a central de jogos que transforma lives em participação ao vivo; personalidade ágil, ousada e acolhedora.
- **Voz:** direta e energética. Exemplos: “Transforme a live em jogo.” / “Conecte o creator. Dispare a rodada.”
- **Marca:** ícone de duas setas curvas formando um elo com um ponto de transmissão ao centro; o nome fica em caixa baixa com peso alto.
- **Cor proprietária:** `#21F4D5`, um aqua elétrico que diferencia o produto dentro da paleta inspirada no TikTok.

## Jogos
1. **Batalha de Likes** — meta de likes, barra de progresso, efeitos de combo e multiplicador.
2. **Chuva de Gifts** — gifts caem na arena e o jogador toca/clica para coletar antes que expirem.
3. **Duelo de Comentários** — comentários simulados escolhem entre dois lados; o usuário faz uma escolha e vence por maioria.
4. **Corrida de Seguidores** — avatares avançam por uma pista conforme novos seguidores chegam.
5. **Caça ao Viral** — memória rápida de cards; o usuário combina ícones da live antes do cronômetro acabar.

Todos terão: tela de conexão, username pré-preenchível, status de monitoramento, contador de eventos, overlay de reações, botão de tela cheia e orientação horizontal simulada via CSS/Fullscreen API.

## Estrutura
- `index.html`: shell, meta tags, fontes e ponto de montagem.
- `src/main.js`: roteamento, estado global e composição da UI.
- `src/styles.css`: sistema visual responsivo e modo jogo horizontal.
- `src/data.js`: catálogo dos jogos, textos e referências de assets.
- `src/storage.js`: JSON local, hash de senha de demonstração, sessão e perfil.
- `src/tiktokLiveConnector.js`: mock de eventos e contrato para futura integração oficial.
- `src/games.js`: renderização e regras dos cinco jogos.
- `public/assets/`: logo, capa e 50 assets de jogo.
- `public/manus-routes.json`: rotas declaradas para Preview.

## Fluxo de build
1. Criar os arquivos do app e inserir assets gerados.
2. Iniciar Vite em `0.0.0.0:3000`.
3. Validar `GET /manus-routes.json`, build e diagnósticos.
4. Inspecionar o fluxo de login, dashboard, perfil e jogos no Preview.
5. Commitar no branch canônico para gerar checkpoint; publicar somente se solicitado depois.
