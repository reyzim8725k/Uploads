import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { TikTokLiveConnection, WebcastEvent, ControlEvent } from 'tiktok-live-connector';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dist = path.join(__dirname, 'dist');
const port = Number(process.env.PORT || 3100);
const clients = new Set();
let active = null;

const initialStats = () => ({ likes: 0, gifts: 0, comments: 0, followers: 0, viewers: 0 });
const state = { username: '', live: false, stats: initialStats(), lastEvent: null };

function json(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(payload);
}

function send(client, type, body) {
  if (!client.writableEnded) client.write(`event: ${type}\ndata: ${JSON.stringify(body)}\n\n`);
}

function broadcast(type, body) {
  for (const client of clients) send(client, type, body);
}

function actor(data) {
  return data?.user?.uniqueId || data?.user?.nickname || data?.user?.displayId || 'viewer';
}

function avatarUrl(data) {
  const values = [
    data?.user?.avatarThumb,
    data?.user?.avatarMedium,
    data?.user?.avatarLarger,
    data?.user?.avatar,
    data?.author?.avatarThumb,
    data?.author?.avatarMedium,
    data?.author?.avatarLarger,
    data?.author?.avatar
  ];
  const flatten = (value) => {
    if (!value) return [];
    if (typeof value === 'string') return [value];
    if (Array.isArray(value)) return value.flatMap(flatten);
    if (typeof value === 'object') return flatten(value.urlList || value.url_list || value.urls || value.url || value.uri);
    return [];
  };
  const url = values.flatMap(flatten).find((candidate) => /^https?:\/\//i.test(candidate));
  return url ? url.replace(/^http:\/\//i, 'https://') : '';
}

function normalize(type, data) {
  const who = actor(data);
  if (type === WebcastEvent.CHAT) {
    state.stats.comments += 1;
    return { type: 'comment', icon: 'comment', color: '#21F4D5', text: `${who} comentou “${data.comment || 'mensagem na live'}”` };
  }
  if (type === WebcastEvent.GIFT) {
    const count = Number(data.repeatCount || 1);
    state.stats.gifts += count;
    const giftName = data.giftName || data.giftDetails?.name || 'um gift';
    return { type: 'gift', icon: 'gift', color: '#FFB84A', text: `${who} enviou ${count > 1 ? `${count}x ` : ''}${giftName}` };
  }
  if (type === WebcastEvent.LIKE) {
    const count = Number(data.likeCount || data.totalLikeCount || 1);
    state.stats.likes += count;
    return { type: 'like', icon: 'heart', color: '#FF2D7A', text: `${who} mandou +${count} likes` };
  }
  if (type === WebcastEvent.FOLLOW) {
    state.stats.followers += 1;
    return { type: 'follow', icon: 'user-plus', color: '#D7FF5F', text: `${who} começou a seguir` };
  }
  if (type === WebcastEvent.SHARE) {
    return { type: 'share', icon: 'external', color: '#B18CFF', text: `${who} compartilhou a live` };
  }
  if (type === WebcastEvent.MEMBER || type === WebcastEvent.ROOM_USER) {
    const viewers = Number(data.viewerCount || data.totalUserCount || data.userCount || 0);
    if (viewers) state.stats.viewers = viewers;
    return { type: 'member', icon: 'users', color: '#21F4D5', text: `${who} entrou na live` };
  }
  return null;
}

async function stopConnection() {
  if (!active) return;
  const old = active;
  active = null;
  try { await old.disconnect(); } catch { /* already closed */ }
  state.live = false;
  broadcast('disconnected', { username: state.username });
}

async function connectLive(username) {
  const clean = String(username || '').replace(/^@/, '').trim();
  if (!clean) throw new Error('Informe um username do TikTok.');
  await stopConnection();
  state.username = clean;
  state.stats = initialStats();
  state.lastEvent = null;
  const connection = new TikTokLiveConnection(clean, {
    processInitialData: false,
    enableExtendedGiftInfo: false,
    fetchRoomInfoOnConnect: true
  });
  active = connection;

  const messageEvents = [WebcastEvent.CHAT, WebcastEvent.GIFT, WebcastEvent.LIKE, WebcastEvent.FOLLOW, WebcastEvent.SHARE, WebcastEvent.MEMBER, WebcastEvent.ROOM_USER];
  for (const eventName of messageEvents) {
    connection.on(eventName, (data) => {
      const event = normalize(eventName, data);
      if (!event || active !== connection) return;
      event.id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
      event.actor = actor(data);
      event.avatar = avatarUrl(data);
      event.points = event.type === 'gift' ? 20 * Number(data?.repeatCount || 1) : event.type === 'follow' ? 10 : event.type === 'like' ? Math.max(3, Math.ceil(Number(data?.likeCount || 1) / 5)) : 1;
      state.lastEvent = event;
      broadcast('event', { event, stats: { ...state.stats } });
    });
  }
  connection.on(ControlEvent.ERROR, (error) => {
    if (active !== connection) return;
    broadcast('error', { message: error?.message || 'O TikTok encerrou a conexão.' });
  });
  connection.on(ControlEvent.DISCONNECTED, () => {
    if (active !== connection) return;
    state.live = false;
    broadcast('disconnected', { username: clean });
  });

  await connection.connect();
  state.live = true;
  broadcast('connected', { username: clean, stats: { ...state.stats } });
  return { username: clean, stats: { ...state.stats } };
}

function serveStatic(req, res) {
  const pathname = new URL(req.url, `http://${req.headers.host}`).pathname;
  const requested = pathname === '/' ? '/index.html' : pathname;
  const safePath = path.normalize(requested).replace(/^\.\.(\/|\\|$)/, '');
  const file = path.join(dist, safePath);
  const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.png': 'image/png', '.ico': 'image/x-icon' }[path.extname(file)] || 'application/octet-stream';
  if (fs.existsSync(file) && fs.statSync(file).isFile()) {
    res.writeHead(200, { 'Content-Type': mime, 'Cache-Control': mime.includes('html') ? 'no-cache' : 'public, max-age=86400' });
    fs.createReadStream(file).pipe(res);
    return;
  }
  const index = path.join(dist, 'index.html');
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
  fs.createReadStream(index).pipe(res);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (req.method === 'GET' && url.pathname === '/api/live/events') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    res.write(': connected\n\n');
    clients.add(res);
    send(res, 'state', { username: state.username, live: state.live, stats: { ...state.stats }, lastEvent: state.lastEvent });
    req.on('close', () => clients.delete(res));
    return;
  }
  if (req.method === 'POST' && url.pathname === '/api/live/connect') {
    let raw = '';
    req.on('data', (chunk) => { raw += chunk; if (raw.length > 4096) req.destroy(); });
    req.on('end', async () => {
      try {
        const body = JSON.parse(raw || '{}');
        const result = await connectLive(body.username);
        json(res, 200, { ok: true, ...result });
      } catch (error) {
        console.error('TikTok live connection failed:', error?.stack || error);
        state.live = false;
        broadcast('error', { message: error?.message || 'Não foi possível conectar à live.' });
        json(res, 422, { ok: false, error: error?.message || 'Não foi possível conectar à live.' });
      }
    });
    return;
  }
  if (req.method === 'POST' && url.pathname === '/api/live/disconnect') {
    await stopConnection();
    json(res, 200, { ok: true });
    return;
  }
  if (req.method === 'GET' && url.pathname === '/api/health') {
    json(res, 200, { ok: true, service: 'tikconector', live: state.live, username: state.username });
    return;
  }
  if (url.pathname.startsWith('/api/')) return json(res, 404, { error: 'Not found' });
  serveStatic(req, res);
});

server.listen(port, '0.0.0.0', () => console.log(`Tik Conector real backend listening on ${port}`));
process.on('SIGTERM', async () => { await stopConnection(); server.close(() => process.exit(0)); });
process.on('SIGINT', async () => { await stopConnection(); server.close(() => process.exit(0)); });
