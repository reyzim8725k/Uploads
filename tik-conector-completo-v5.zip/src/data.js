export const brand = {
  name: 'Tik Conector', eyebrow: 'LIVE PLAYGROUND', accent: '#21F4D5', magenta: '#FF2D7A',
  logo: '/assets/site/logo-mark.svg', cover: '/assets/generated/6jwBs96CAje1zDl8qXbG4-image-2.webp', avatar: '/assets/generated/6jwBs96CAje1zDl8qXbG4-image-3.webp'
};

export const boysGirlsVisuals = {
  cover: '/assets/boys-girls/capa.webp',
  teamBoys: '/assets/boys-girls/team_boys.webp',
  teamGirls: '/assets/boys-girls/team_girls.webp',
  vs: '/assets/boys-girls/emblema_vs.webp',
  background: '/assets/boys-girls/arena.webp',
  boysAttack: '/assets/boys-girls/ataque_boys.webp',
  boysImpact: '/assets/boys-girls/impacto_boys.webp',
  boysShield: '/assets/boys-girls/escudo_boys.webp',
  boysBoost: '/assets/boys-girls/boost_boys.webp',
  boysMedal: '/assets/boys-girls/medal_boys.webp',
  girlsAttack: '/assets/boys-girls/team_girls.webp',
  girlsImpact: '/assets/boys-girls/team_girls.webp',
  girlsShield: '/assets/boys-girls/team_girls.webp',
  girlsBoost: '/assets/boys-girls/team_girls.webp',
  girlsMedal: '/assets/boys-girls/team_girls.webp',
  girlsChibi: '/assets/boys-girls/team_girls.webp',
  boysChibi: '/assets/boys-girls/team_boys.webp',
  ball: '/assets/boys-girls/emblema_vs.webp',
  divider: '/assets/boys-girls/emblema_vs.webp',
  verticalBackground: '/assets/boys-girls/arena.webp'
};

export const games = [{
  id: 'boys-vs-girls', number: '01', title: 'Boys vs Girls', short: 'A batalha da live.',
  description: 'Comente BOY ou GIRL, entre na sua equipe e ajude seu time a chegar aos 100 pontos.',
  label: 'TEAM BATTLE', metric: 'battle', accent: '#21F4D5',
  gradient: 'linear-gradient(135deg, #102f49 0%, #161629 52%, #3b1639 100%)', icon: 'swords', assets: []
}];

export const navItems = [
  { id: 'app', label: 'Jogo', icon: 'grid' },
  { id: 'activity', label: 'Atividade', icon: 'pulse' },
  { id: 'profile', label: 'Perfil', icon: 'user' }
];
