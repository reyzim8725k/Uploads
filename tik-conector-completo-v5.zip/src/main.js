import { brand, games, navItems, boysGirlsVisuals } from './data.js';
import { addRecentGame, demoLogin, getCurrentUser, getStore, login, logout, register, setConnectedUsername, updateUser } from './storage.js';
import { TikTokLiveConnector } from './tiktokLiveConnector.js';
import './styles.css';

const app = document.querySelector('#app');
const connector = new TikTokLiveConnector();
const storeAtStart = getStore();
const state = {
  user: getCurrentUser(storeAtStart),
  connection: { username: storeAtStart.connectedUsername || '', live: false, stats: { likes: 0, gifts: 0, comments: 0, followers: 0, viewers: 0 } },
  lastEvents: [],
  liveLeaderboard: [],
  gameSession: null,
  toastTimer: null
};

const escapeHtml = (value = '') => String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
const formatNumber = (value) => new Intl.NumberFormat('pt-BR', { notation: 'compact', maximumFractionDigits: 1 }).format(value || 0);
const getPath = () => window.location.hash.replace(/^#/, '') || (state.user ? '/app' : '/login');
const route = () => getPath().split('?')[0];
const navigate = (path) => { window.location.hash = path; };

function icon(name, size = 18) {
  const paths = {
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    pulse: '<path d="M3 12h3l2.2-6 4.1 12 2.2-6H21"/>',
    user: '<circle cx="12" cy="8" r="3.5"/><path d="M5 21c.7-3.4 3-5.2 7-5.2s6.3 1.8 7 5.2"/>',
    'user-plus': '<circle cx="9" cy="8" r="3.4"/><path d="M2.8 21c.7-3.2 2.8-5 6.2-5s5.5 1.8 6.2 5M19 8v6M16 11h6"/>',
    heart: '<path d="M20.8 8.8c0 5-8.8 10.2-8.8 10.2S3.2 13.8 3.2 8.8A4.6 4.6 0 0 1 12 6.1a4.6 4.6 0 0 1 8.8 2.7Z"/>',
    gift: '<path d="M4 11h16v10H4zM3 7h18v4H3zM12 7v14M12 7H8.2C5 7 5.2 2.8 8.1 3.4 10.4 3.8 12 7 12 7Zm0 0h3.8c3.2 0 3-4.2.1-3.6C13.6 3.8 12 7 12 7Z"/>',
    comment: '<path d="M20 11.2c0 4.5-3.6 7.2-8 7.2-1.1 0-2.1-.2-3-.5L4 20l1.3-3.9A6.8 6.8 0 0 1 4 11.2C4 6.7 7.6 4 12 4s8 2.7 8 7.2Z"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3.5 20c.5-3 2.3-4.5 5.5-4.5s5 1.5 5.5 4.5M17 5.3a3 3 0 0 1 0 5.5M16 15.5c2.5.2 4 1.7 4.5 4.5"/>',
    sparkles: '<path d="m12 3 1.3 5.2L18 10l-4.7 1.8L12 17l-1.3-5.2L6 10l4.7-1.8L12 3ZM19 16l.6 2.4L22 19l-2.4.6L19 22l-.6-2.4L16 19l2.4-.6L19 16Z"/>',
    'arrow-right': '<path d="M4 12h15M13 6l6 6-6 6"/>',
    'chevron-right': '<path d="m9 5 7 7-7 7"/>',
    play: '<path d="m8 5 11 7-11 7V5Z"/>',
    expand: '<path d="M8 3H3v5M16 3h5v5M21 16v5h-5M3 16v5h5"/>',
    'log-out': '<path d="M10 4H4v16h6M14 8l4 4-4 4M18 12H8"/>',
    settings: '<path d="M12 8.8a3.2 3.2 0 1 0 0 6.4 3.2 3.2 0 0 0 0-6.4Z"/><path d="m19.4 15 .1.1a1.8 1.8 0 0 1-2.5 2.5l-.1-.1a1.8 1.8 0 0 0-3.1 1.3v.2a1.8 1.8 0 0 1-3.6 0v-.2a1.8 1.8 0 0 0-3.1-1.3l-.1.1a1.8 1.8 0 0 1-2.5-2.5l.1-.1A1.8 1.8 0 0 0 3.3 12a1.8 1.8 0 0 0-1.3-3.1h-.2a1.8 1.8 0 0 1 0-3.6H2A1.8 1.8 0 0 0 3.3 2.2l-.1-.1a1.8 1.8 0 0 1 2.5-2.5l.1.1A1.8 1.8 0 0 0 8.9-1.6V-2a1.8 1.8 0 0 1 3.6 0v.2a1.8 1.8 0 0 0 3.1 1.3l.1-.1a1.8 1.8 0 0 1 2.5 2.5l-.1.1A1.8 1.8 0 0 0 19.4 5a1.8 1.8 0 0 1 1.3 3.1h-.2a1.8 1.8 0 0 0-1.1 3.1Z"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/>',
    lock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    eye: '<path d="M2.5 12s3.3-5 9.5-5 9.5 5 9.5 5-3.3 5-9.5 5-9.5-5-9.5-5Z"/><circle cx="12" cy="12" r="2.4"/>',
    at: '<circle cx="12" cy="12" r="8.5"/><path d="M16 15c-1.4 1.8-4 1.7-5.3.4-1.7-1.7-.8-5.4 1.8-6.2 2.4-.7 4.5 1.2 4.1 3.5-.3 1.9-2.5 2.7-3.9 1.5-1.4-1.2-.5-3.7 1.4-3.7 1.3 0 2.1 1.2 1.8 2.4"/>',
    bolt: '<path d="m13 2-9 12h7l-1 8 9-12h-7l1-8Z"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    refresh: '<path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v6h-6"/>',
    trophy: '<path d="M8 4h8v5a4 4 0 0 1-8 0V4ZM12 13v4M8 21h8M6 5H3v2a4 4 0 0 0 4 4M18 5h3v2a4 4 0 0 1-4 4"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3 2"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
    monitor: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>',
    external: '<path d="M14 4h6v6M20 4l-9 9M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4"/>'
  };
  return `<svg class="icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.sparkles}</svg>`;
}

function showToast(message, tone = 'default') {
  const root = document.querySelector('#toast-root');
  if (!root) return;
  root.innerHTML = `<div class="toast toast-${tone}">${icon(tone === 'success' ? 'check' : 'bolt', 15)}<span>${escapeHtml(message)}</span></div>`;
  window.clearTimeout(state.toastTimer);
  state.toastTimer = window.setTimeout(() => { root.innerHTML = ''; }, 3400);
}

function authView(mode = 'login') {
  const isRegister = mode === 'register';
  return `
    <main class="auth-layout">
      <section class="auth-art" style="--auth-cover: url('${brand.cover}')">
        <div class="auth-art-scrim"></div>
        <div class="auth-brand"><span class="brand-mark"><img src="${brand.logo}" alt="" /></span><span>Tik<br/>Conector</span></div>
        <div class="auth-art-copy"><span class="eyebrow">${brand.eyebrow}</span><h1>Transforme a<br/><em>live em jogo.</em></h1><p>Conecte a audiência, acompanhe cada sinal e crie momentos que ninguém esquece.</p><div class="mini-proof"><span class="proof-dot"></span><span><b>1.2k</b> creators jogando agora</span></div></div>
        <div class="art-orbit orbit-one"></div><div class="art-orbit orbit-two"></div>
      </section>
      <section class="auth-panel">
        <div class="auth-panel-inner">
          <div class="auth-mobile-brand"><span class="brand-mark"><img src="${brand.logo}" alt="" /></span><b>Tik Conector</b></div>
          <div class="auth-heading"><span class="eyebrow">${isRegister ? 'COMECE SUA SESSÃO' : 'BEM-VINDO DE VOLTA'}</span><h2>${isRegister ? 'Crie seu playground.' : 'Sua live.\nSua arena.'}</h2><p>${isRegister ? 'Um painel simples para transformar audiência em participação.' : 'Entre e transforme a energia da sua live em um jogo ao vivo.'}</p></div>
          <form class="auth-form" data-form="${isRegister ? 'register' : 'login'}">
            ${isRegister ? `<label>Seu nome<input name="name" type="text" placeholder="Como quer ser chamado?" autocomplete="name" required /></label>` : ''}
            <label>E-mail<input name="email" type="email" placeholder="voce@email.com" autocomplete="email" required /></label>
            <label>Senha<div class="input-with-icon"><input name="password" type="password" placeholder="Mínimo de 6 caracteres" autocomplete="current-password" minlength="6" required /><button type="button" class="input-action" data-toggle-password>${icon('eye', 17)}</button></div></label>
            <button class="primary-button wide" type="submit"><span>${isRegister ? 'Criar minha conta' : 'Entrar no Tik Conector'}</span>${icon('arrow-right', 17)}</button>
          </form>
          <button class="demo-button" data-demo-login><span class="demo-icon">✦</span> Entrar na demo com um toque</button>
          <div class="auth-separator"><span>ou</span></div>
          <p class="auth-switch">${isRegister ? 'Já tem uma conta?' : 'Ainda não tem conta?'} <a href="#/${isRegister ? 'login' : 'register'}">${isRegister ? 'Entrar agora' : 'Criar gratuitamente'}</a></p>
          <p class="auth-legal">Ao continuar, você concorda com os termos do Tik Conector.<br/>A prévia usa dados locais no seu navegador.</p>
        </div>
      </section>
    </main>`;
}

function shell(content, active = 'app') {
  const user = state.user || {};
  return `<div class="app-shell">
    <aside class="sidebar">
      <a href="#/app" class="sidebar-brand"><span class="brand-mark"><img src="${brand.logo}" alt="" /></span><span>Tik<br/>Conector</span></a>
      <div class="sidebar-live"><span class="status-dot ${state.connection.live ? 'is-live' : ''}"></span><span>${state.connection.live ? 'Live conectada' : 'Aguardando live'}</span></div>
      <nav class="side-nav">${navItems.map((item) => `<a class="nav-item ${active === item.id ? 'is-active' : ''}" href="#/${item.id === 'app' ? 'app' : item.id}">${icon(item.icon, 18)}<span>${item.label}</span>${item.id === 'activity' ? '<b class="nav-badge">3</b>' : ''}</a>`).join('')}</nav>
      <div class="sidebar-bottom"><div class="tip-card"><span class="tip-spark">✦</span><div><b>Ative o modo criador</b><p>Jogue junto com sua audiência.</p></div>${icon('arrow-right', 15)}</div><button class="nav-item subtle" data-logout>${icon('log-out', 18)}<span>Sair da conta</span></button></div>
    </aside>
    <div class="mobile-topbar"><a href="#/app" class="mobile-brand"><span class="brand-mark"><img src="${brand.logo}" alt="" /></span><b>Tik Conector</b></a><a href="#/profile" class="avatar-button"><img src="${user.avatar || brand.avatar}" alt="Avatar de ${escapeHtml(user.name || 'creator')}" /></a></div>
    <main class="main-area">${content}</main>
    <nav class="bottom-nav">${navItems.map((item) => `<a class="bottom-item ${active === item.id ? 'is-active' : ''}" href="#/${item.id === 'app' ? 'app' : item.id}">${icon(item.icon, 19)}<span>${item.label}</span></a>`).join('')}</nav>
  </div>`;
}

function statPill(label, value, kind, iconName) {
  return `<div class="stat-pill"><span class="stat-icon stat-${kind}">${icon(iconName, 16)}</span><div><small>${label}</small><strong data-stat="${kind}">${formatNumber(value)}</strong></div></div>`;
}

function gameCard(game, index) {
  return `<a class="game-card" href="#/game/${game.id}" data-game-route="/game/${game.id}" role="button" style="--game-accent:${game.accent};--game-gradient:${game.gradient}">
    <div class="game-card-bg" style="background-image:url('${boysGirlsVisuals.cover}')"></div><div class="game-card-top"><span class="game-number">${game.number}</span><span class="game-label">${game.label}</span>${icon('arrow-right', 17)}</div>
    <div class="game-card-copy"><h3>${game.title}</h3><p>${game.short}</p></div>
    <div class="game-card-assets"><img src="${boysGirlsVisuals.teamBoys}" alt="Team Boys" class="card-asset asset-0" loading="lazy"/><img src="${boysGirlsVisuals.vs}" alt="VS" class="card-asset asset-1" loading="lazy"/><img src="${boysGirlsVisuals.teamGirls}" alt="Team Girls" class="card-asset asset-2" loading="lazy"/></div>
    <div class="game-card-bottom"><span><span class="live-mini-dot"></span> interativo em tempo real</span><span class="play-link">Jogar ${icon('play', 12)}</span></div>
  </a>`;
}

function dashboardView() {
  const user = state.user;
  const stats = state.connection.stats;
  const feed = state.lastEvents.length ? state.lastEvents : [{ type: 'empty', icon: 'pulse', text: 'Nenhum evento real recebido ainda.', color: '#7C8498' }];
  return shell(`<div class="page-wrap dashboard-page">
    <header class="page-header"><div><span class="eyebrow">PAINEL DE CONTROLE</span><h1>Bom te ver, <em>${escapeHtml(user.name.split(' ')[0])}.</em></h1><p>Pronto para colocar sua audiência para jogar?</p></div><div class="header-actions"><div class="desktop-live-state"><span class="status-dot ${state.connection.live ? 'is-live' : ''}"></span>${state.connection.live ? 'LIVE ONLINE' : 'OFFLINE'}</div><a href="#/profile" class="profile-chip"><img src="${user.avatar || brand.avatar}" alt=""/><span>@${escapeHtml(user.name.toLowerCase().replaceAll(' ', '.'))}</span>${icon('chevron-right', 15)}</a></div></header>
    <section class="live-hero" style="--hero-image:url('${brand.cover}')"><div class="hero-backdrop"></div><div class="hero-content"><div class="hero-kicker"><span class="live-badge"><span></span> ${state.connection.live ? 'LIVE MONITORADA' : 'PRONTA PARA CONECTAR'}</span><span class="hero-time">${icon('pulse', 13)} atualização em tempo real</span></div><h2>A audiência está<br/><em>esperando você.</em></h2><p>Conecte o username de uma live pública do TikTok e receba eventos reais.</p><form class="connect-form" data-form="connect"><span class="connect-at">@</span><input name="username" value="${escapeHtml(state.connection.username || user.tiktokUsername || '')}" placeholder="username do TikTok" aria-label="Username do TikTok" required /><button class="primary-button" type="submit">${state.connection.live ? 'Trocar live' : 'Conectar live'} ${icon('arrow-right', 16)}</button></form><div class="hero-note"><span class="secure-dot">${icon('check', 11)}</span> conector real · eventos públicos da live</div></div><div class="hero-orbit"><div class="hero-orbit-ring"></div><div class="hero-orbit-core">${icon('pulse', 26)}</div><span class="float-bubble bubble-heart">${icon('heart', 18)}</span><span class="float-bubble bubble-gift">${icon('gift', 17)}</span><span class="float-bubble bubble-comment">${icon('comment', 17)}</span></div></section>
    <section class="metric-row">${statPill('Likes na live', stats.likes, 'likes', 'heart')}${statPill('Gifts recebidos', stats.gifts, 'gifts', 'gift')}${statPill('Comentários', stats.comments, 'comments', 'comment')}${statPill('Novos seguidores', stats.followers, 'followers', 'user-plus')}</section>
    <div class="section-heading"><div><span class="eyebrow">PLAYGROUND</span><h2>Escolha uma arena</h2></div><a class="text-link" href="#/app">Ver todos ${icon('arrow-right', 14)}</a></div>
    <section class="games-grid">${games.map(gameCard).join('')}</section>
    <section class="lower-grid"><div class="activity-panel"><div class="panel-heading"><div><span class="eyebrow">LIVE FEED</span><h3>O que está acontecendo</h3></div><span class="live-badge small"><span></span> ao vivo</span></div><div class="event-list" id="live-feed">${feed.map(eventRow).join('')}</div></div><div class="quick-panel"><span class="eyebrow">SEU RITMO</span><div class="quick-score"><strong>18</strong><span>sessões<br/>jogadas</span>${icon('trophy', 25)}</div><div class="score-line"><span>melhor pontuação</span><b>${formatNumber(user.bestScore || 8420)}</b></div><a class="secondary-button wide" href="#/profile">Ver meu perfil ${icon('arrow-right', 15)}</a></div></section>
  </div>`, 'app');
}

function eventRow(event) {
  return `<div class="event-row"><span class="event-icon" style="--event-color:${event.color || '#21F4D5'}">${icon(event.icon || 'pulse', 15)}</span><span>${escapeHtml(event.text)}</span><time>agora</time></div>`;
}

function profileView() {
  const user = state.user;
  return shell(`<div class="page-wrap profile-page"><header class="page-header profile-header"><div><span class="eyebrow">IDENTIDADE</span><h1>Seu <em>perfil.</em></h1><p>Deixe sua assinatura pronta para a próxima live.</p></div><button class="secondary-button" data-logout>${icon('log-out', 16)} Sair</button></header><section class="profile-hero"><div class="profile-avatar-wrap"><img class="profile-avatar" src="${user.avatar || brand.avatar}" alt="Avatar de ${escapeHtml(user.name)}"/><span class="avatar-live-dot"></span></div><div><span class="eyebrow">CREATOR PROFILE</span><h2>${escapeHtml(user.name)}</h2><p>@${escapeHtml(user.tiktokUsername || 'conecte-seu-tiktok')}</p><span class="profile-status"><span class="status-dot ${state.connection.live ? 'is-live' : ''}"></span>${state.connection.live ? 'Conectado agora' : 'Disponível para conectar'}</span></div><div class="profile-stats"><div><b>${user.gamesPlayed || 0}</b><span>sessões</span></div><div><b>${formatNumber(user.bestScore || 0)}</b><span>recorde</span></div><div><b>4.8k</b><span>interações</span></div></div></section><div class="profile-grid"><section class="profile-panel"><div class="panel-heading"><div><span class="eyebrow">DETALHES</span><h3>Como o público te encontra</h3></div>${icon('settings', 19)}</div><form class="profile-form" data-form="profile"><label>Nome de exibição<input name="name" value="${escapeHtml(user.name)}" required /></label><label>Username do TikTok<div class="input-with-icon"><span class="field-prefix">@</span><input name="tiktokUsername" value="${escapeHtml(user.tiktokUsername || '')}" placeholder="seu.username" /></div></label><label>Bio<textarea name="bio" rows="3" maxlength="100">${escapeHtml(user.bio || '')}</textarea></label><button class="primary-button" type="submit">Salvar alterações ${icon('check', 16)}</button></form></section><section class="profile-panel connected-panel"><div class="panel-heading"><div><span class="eyebrow">CONEXÃO</span><h3>Sua live monitorada</h3></div><span class="live-badge small ${state.connection.live ? '' : 'muted'}"><span></span>${state.connection.live ? 'online' : 'offline'}</span></div><div class="connected-live-card"><div class="connected-live-icon">${icon('pulse', 22)}</div><div><b>@${escapeHtml(state.connection.username || user.tiktokUsername || 'nenhum username')}</b><p>${state.connection.live ? 'Eventos chegando em tempo real' : 'Conecte uma live no dashboard'}</p></div></div><a href="#/app" class="secondary-button wide">Gerenciar conexão ${icon('arrow-right', 15)}</a></section></div></div>`, 'profile');
}

function activityView() {
  const events = state.lastEvents.length ? state.lastEvents : [{ icon: 'pulse', text: 'Conecte uma live pública para receber eventos reais.', color: '#7C8498' }];
  return shell(`<div class="page-wrap activity-page"><header class="page-header"><div><span class="eyebrow">STREAM SIGNALS</span><h1>Sua <em>atividade.</em></h1><p>Todos os sinais da live, em um só lugar.</p></div><span class="live-badge"><span></span> ${state.connection.live ? 'monitorando' : 'aguardando conexão'}</span></header><div class="activity-dashboard"><section class="activity-big-card"><span class="eyebrow">PULSO DA LIVE</span><div class="pulse-visual"><div class="pulse-ring ring-a"></div><div class="pulse-ring ring-b"></div><div class="pulse-core">${icon('pulse', 28)}</div></div><h2>${state.connection.live ? 'A live está respirando.' : 'Pronto para sentir o pulso?'}</h2><p>${state.connection.live ? `@${escapeHtml(state.connection.username)} está enviando sinais para sua arena.` : 'Conecte um username para começar a monitorar.'}</p><a href="#/app" class="primary-button">${state.connection.live ? 'Abrir playground' : 'Conectar agora'} ${icon('arrow-right', 16)}</a></section><section class="activity-list-panel"><div class="panel-heading"><div><span class="eyebrow">TIMELINE</span><h3>Eventos recentes</h3></div><span class="mono-label">LIVE / 24H</span></div><div class="event-list tall">${events.concat(events).slice(0, 7).map(eventRow).join('')}</div></section></div></div>`, 'activity');
}

function gameStateFor(game) {
  if (!state.gameSession || state.gameSession.id !== game.id) {
    state.gameSession = { id: game.id, boys: [], girls: [], teamPoints: { boys: 0, girls: 0 }, roundWins: { boys: 0, girls: 0 }, round: 1, feed: [], shots: [], likesSeen: [], followsSeen: [], startedAt: 0, roundEndsAt: 0 };
  }
  if (state.connection.live && !state.gameSession.roundEndsAt) { state.gameSession.startedAt = Date.now(); state.gameSession.roundEndsAt = Date.now() + 300000; }
  return state.gameSession;
}

function battlePoints(event) {
  if (event.type === 'gift') return Math.max(20, Number(event.points || 20));
  if (event.type === 'like') return 3;
  if (event.type === 'follow') return 10;
  return 1;
}

const TEAM_ZONES = { girls: { minX: 6, maxX: 44 }, boys: { minX: 56, maxX: 94 } };
const randomIn = (min, max) => min + Math.random() * (max - min);
const clockText = (session) => {
  const seconds = Math.max(0, Math.ceil((session.roundEndsAt - Date.now()) / 1000));
  return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
};
function spawnPosition(team) {
  const zone = TEAM_ZONES[team];
  return { x: randomIn(zone.minX, zone.maxX), y: randomIn(16, 84) };
}
let shotSeq = 0;
function fireShot(team, from, target, at = performance.now()) {
  const session = state.gameSession;
  if (!session) return;
  session.shots.push({ id: ++shotSeq, team, shooter: from.name, fromX: from.x, fromY: from.y, target, targetTeam: team === 'boys' ? 'girls' : 'boys', dmg: Math.max(1, from.damage / 10), born: at, hit: false });
  if (session.shots.length > 120) session.shots.splice(0, session.shots.length - 120);
}

function resolveHit(s) {
  const session = state.gameSession;
  const list = session[s.targetTeam];
  // Se o alvo já saiu do campo, o tiro acerta outro inimigo vivo: nenhum tiro é perdido
  if (list.indexOf(s.target) < 0) {
    if (!list.length) return;
    s.target = list[Math.floor(Math.random() * list.length)];
  }
  const idx = list.indexOf(s.target);
  s.target.hp -= s.dmg;
  s.target.lastHit = performance.now();
  if (s.target.hp <= 0) {
    list.splice(idx, 1);
    session.teamPoints[s.team] += 5;
    session.feed.unshift({ text: `${s.shooter} eliminou ${s.target.name}`, team: s.team, kind: 'elimination' });
    session.feed = session.feed.slice(0, 8);
    session.dirty = true;
  }
}

function joinBattle(team, event) {
  if (!event?.actor || state.gameSession?.id !== 'boys-vs-girls') return;
  const key = event.actor;
  const list = team === 'boys' ? state.gameSession.boys : state.gameSession.girls;
  let fighter = list.find((item) => item.id === key);
  const points = battlePoints(event);
  if (list.length >= 200 && !fighter) return;
  if (!fighter) {
    const start = spawnPosition(team);
    fighter = { id: key, name: key.replace(/^@/, ''), avatar: event.avatar || '', hp: event.type === 'gift' ? 160 : 100, maxHp: event.type === 'gift' ? 160 : 100, damage: event.type === 'gift' ? 24 : 10, points: 0, x: start.x, y: start.y, tx: start.x, ty: start.y, nextMoveAt: 0 };
    list.push(fighter);
  } else if (event.type === 'gift') {
    fighter.maxHp += 35;
    fighter.hp = Math.min(fighter.maxHp, fighter.hp + 35);
    fighter.damage += 8;
    fighter.gifts = (fighter.gifts || 0) + 1;
  }
  fighter.avatar = event.avatar || fighter.avatar;
  fighter.points += points;
  fighter.hp = Math.min(fighter.maxHp, fighter.hp + (event.type === 'gift' ? 12 : 4));
  fighter.attackAt = Date.now();
  state.gameSession.teamPoints[team] += points;
  state.gameSession.feed.unshift({ text: `${fighter.name} entrou no Team ${team === 'boys' ? 'Boys' : 'Girls'}`, team, kind: event.type });
  state.gameSession.feed = state.gameSession.feed.slice(0, 8);
}

function finishRoundIfNeeded() {
  const session = state.gameSession;
  if (!session || session.id !== 'boys-vs-girls' || !session.roundEndsAt || Date.now() < session.roundEndsAt) return;
  const winner = session.teamPoints.boys === session.teamPoints.girls ? null : session.teamPoints.boys > session.teamPoints.girls ? 'boys' : 'girls';
  if (winner) session.roundWins[winner] += 1;
  session.feed.unshift({ text: winner ? `Team ${winner === 'boys' ? 'Boys' : 'Girls'} venceu a rodada ${session.round}` : `Rodada ${session.round} terminou empatada`, team: winner || 'neutral', kind: 'round' });
  session.round += 1;
  session.teamPoints = { boys: 0, girls: 0 };
  session.boys = []; session.girls = []; session.shots = [];
  session.likesSeen = []; session.followsSeen = [];
  session.roundEndsAt = Date.now() + 300000;
}

function applyBattleSignal(event) {
  if (!event?.actor || state.gameSession?.id !== 'boys-vs-girls') return;
  const text = `${event.text || ''} ${event.actor || ''}`.toLowerCase();
  if (event.type === 'comment') {
    const alreadyJoined = state.gameSession.boys.some((fighter) => fighter.id === event.actor) || state.gameSession.girls.some((fighter) => fighter.id === event.actor);
    if (!alreadyJoined && /\bboy(s)?\b/.test(text)) joinBattle('boys', event);
    if (!alreadyJoined && /\bgirl(s)?\b/.test(text)) joinBattle('girls', event);
  } else if (event.type === 'like') {
    const alreadyJoined = state.gameSession.boys.some((fighter) => fighter.id === event.actor) || state.gameSession.girls.some((fighter) => fighter.id === event.actor);
    if (!alreadyJoined && !state.gameSession.likesSeen.includes(event.actor)) { state.gameSession.likesSeen.push(event.actor); joinBattle('boys', event); }
  } else if (event.type === 'follow') {
    const alreadyJoined = state.gameSession.boys.some((fighter) => fighter.id === event.actor) || state.gameSession.girls.some((fighter) => fighter.id === event.actor);
    if (!alreadyJoined && !state.gameSession.followsSeen.includes(event.actor)) { state.gameSession.followsSeen.push(event.actor); joinBattle('girls', event); }
  } else if (event.type === 'gift') {
    const existingTeam = state.gameSession.boys.some((fighter) => fighter.id === event.actor) ? 'boys' : state.gameSession.girls.some((fighter) => fighter.id === event.actor) ? 'girls' : null;
    const team = existingTeam || (state.gameSession.boys.length <= state.gameSession.girls.length ? 'boys' : 'girls');
    joinBattle(team, event);
  }
}

function gameHud(game, session) {
  const statLabel = game.id === 'boys-vs-girls' ? 'PONTOS DA RODADA' : 'PONTUAÇÃO';
  const value = game.id === 'boys-vs-girls' ? `${session.teamPoints.boys} : ${session.teamPoints.girls}` : session.score;
  const clock = clockText(session);
  return `<div class="game-hud"><div><span class="eyebrow">${game.label}</span><strong data-game-score>${typeof value === 'number' ? formatNumber(value) : value}</strong><small>${statLabel}</small></div><div class="game-hud-divider"></div><div><span class="eyebrow">ROUND ${session.round}</span><strong class="round-clock">${clock}</strong><small>tempo restante</small></div><div class="game-hud-actions"><span class="live-badge small"><span></span> online</span><button class="icon-button" data-fullscreen title="Tela cheia">${icon('expand', 17)}</button></div></div>`;
}

function fighterCard(fighter, team) {
  const hp = Math.max(0, Math.round(fighter.hp / fighter.maxHp * 100));
  return `<div class="fighter-card ${team} ${fighter.hp < fighter.maxHp * .35 ? 'critical' : ''}"><div class="fighter-avatar"><img src="${escapeHtml(fighter.avatar || brand.avatar)}" alt="" onerror="this.style.display='none'"/><span class="fighter-level">${fighter.maxHp > 100 ? 'GIFT' : 'LIVE'}</span></div><div class="fighter-meta"><b>${escapeHtml(fighter.name)}</b><span>${fighter.points} pts</span><div class="fighter-hp"><i style="width:${hp}%"></i></div></div><div class="fighter-life">${hp}%</div></div>`;
}

function battleTeam(team, fighters) {
  const isBoys = team === 'boys';
  return `<section class="battle-team ${team}"><div class="team-banner"><div><span class="eyebrow">TEAM</span><h2>${isBoys ? 'BOYS' : 'GIRLS'}</h2><p>${fighters.length} combatentes em campo</p></div><img src="${isBoys ? boysGirlsVisuals.teamBoys : boysGirlsVisuals.teamGirls}" alt="Team ${team}" onerror="this.style.display='none'"/></div><div class="fighters-list">${fighters.length ? fighters.map((fighter) => fighterCard(fighter, team)).join('') : `<div class="battle-empty">Comente <b>${isBoys ? 'BOY' : 'GIRL'}</b><br/>para nascer nesta equipe</div>`}</div><div class="team-points"><span>PONTOS DA RODADA</span><strong>${state.gameSession.teamPoints[team]}<small>/100</small></strong><div><i style="width:${Math.min(100, state.gameSession.teamPoints[team])}%"></i></div></div></section>`;
}

function battleFighterAvatar(fighter, team) {
  const hp = Math.max(0, Math.round(fighter.hp / fighter.maxHp * 100));
  const size = Math.min(1.55, 1 + ((fighter.maxHp - 100) / 35) * 0.08);
  return `<div class="battle-orb fighter-${team} ${fighter.hp < fighter.maxHp * .35 ? 'critical' : ''} ${fighter.gifts ? 'gift-powered' : ''}" data-fighter-id="${escapeHtml(fighter.id)}" data-team="${team}" style="left:${fighter.x}%;top:${fighter.y}%;--orb-scale:${size}" title="${escapeHtml(fighter.name)} · vida ${hp}%"><div class="orb-hp"><i style="width:${hp}%"></i><span>${hp}%</span></div><div class="orb-photo"><img src="${escapeHtml(fighter.avatar || brand.avatar)}" alt="Foto de ${escapeHtml(fighter.name)}" onerror="this.onerror=null;this.src='${brand.avatar}'"/><span class="orb-gift">${fighter.gifts ? `G${fighter.gifts}` : 'LIVE'}</span></div><b class="orb-name">${escapeHtml(fighter.name)}</b></div>`;
}
function gameArena(game, session) {
  const fighters = [
    ...session.girls.slice(0, 200).map((f) => battleFighterAvatar(f, 'girls')),
    ...session.boys.slice(0, 200).map((f) => battleFighterAvatar(f, 'boys'))
  ].join('');
  const feed = session.feed.length
    ? session.feed.slice(0, 4).map((item) => `<div class="live-battle-chat ${item.team}"><span>${item.kind === 'elimination' ? 'KO' : item.kind === 'gift' ? 'GIFT' : '✦'}</span><b>${escapeHtml(item.text)}</b></div>`).join('')
    : '<div class="live-battle-chat neutral"><span>LIVE</span><b>Comente GIRL ou BOY para virar um combatente.</b></div>';
  const rules = `<aside class="live-battle-rules" aria-label="Regras da batalha">
      <b>COMO ENTRAR</b>
      <div class="rule"><strong>Comente GIRL</strong><small>entra no Team Girls</small></div>
      <div class="rule boys"><strong>Comente BOY</strong><small>entra no Team Boys</small></div>
      <div class="rule"><strong>Seguir</strong><small>entra no Team Girls</small></div>
      <div class="rule boys"><strong>Curtir</strong><small>entra no Team Boys</small></div>
      <div class="rule gift"><strong>Presente 🎁</strong><small>bolinha maior, mais vida e dano</small></div>
      <small class="rule-foot">Quem está na batalha atira sem parar. Primeiro a 100 pontos vence a rodada.</small>
    </aside>`;
  return `<div class="game-arena live-battle-arena" style="--live-battle-bg:url('${boysGirlsVisuals.verticalBackground}')">
    <div class="live-battle-layout">
      <div class="live-battle-center">
        <div class="live-battle-top">
          <div class="live-team-score girls-score"><span>GIRLS</span><b>${session.teamPoints.girls}</b><small>ROUND ${session.roundWins.girls}</small></div>
          <div class="live-battle-title"><span>LIVE BATTLE</span><strong>GIRLS <i>VS</i> BOYS</strong><small>primeiro a 100 pontos</small></div>
          <div class="live-team-score boys-score"><span>BOYS</span><b>${session.teamPoints.boys}</b><small>ROUND ${session.roundWins.boys}</small></div>
        </div>
        <div class="live-battle-stage individual-battle-stage">
          <div class="battle-field">
            ${fighters || '<span class="live-empty-command">comente GIRL ou BOY para entrar</span>'}
            <div class="battle-projectiles" aria-hidden="true"></div>
          </div>
          <div class="live-side girls-side"><div class="live-team-label"><span>G</span><div><b>GIRLS</b><small>COMENTE GIRL</small></div></div></div>
          <div class="live-center-action">
            <div class="live-energy-divider"></div>
            <img class="live-ball" src="${boysGirlsVisuals.ball}" alt="Bola em disputa" onerror="this.style.display='none'"/>
            <div class="live-impact-word">${session.feed[0]?.kind === 'elimination' ? 'KO!' : session.feed[0]?.kind === 'gift' ? 'POWER!' : 'FIGHT!'}</div>
            <img class="live-divider-art" src="${boysGirlsVisuals.divider}" alt="Raio" onerror="this.style.display='none'"/>
          </div>
          <div class="live-side boys-side"><div class="live-team-label"><span>B</span><div><b>BOYS</b><small>COMENTE BOY</small></div></div></div>
        </div>
        <div class="live-battle-chatlist">${feed}</div>
      </div>
      ${rules}
    </div>
  </div>`;
}

function gameView(id) {
  const game = games.find((candidate) => candidate.id === id) || games[0];
  const session = gameStateFor(game);
  const connected = state.connection.live;
  return `<div class="game-page" style="--game-accent:${game.accent};--game-gradient:${game.gradient}"><header class="game-topbar"><a href="#/app" class="back-link">${icon('chevron-right', 18)} <span>voltar para arenas</span></a><div class="game-top-title"><span class="game-number">${game.number}</span><b>${game.title}</b><span class="game-label">${game.label}</span></div><div class="game-top-actions"><span class="connected-user"><span class="status-dot ${connected ? 'is-live' : ''}"></span>@${escapeHtml(state.connection.username || 'conecte sua live')}</span><button class="icon-button" data-fullscreen title="Tela cheia horizontal">${icon('expand', 17)}</button></div></header><main class="game-stage">${connected ? `<div class="game-stage-head"><div><span class="eyebrow">${game.short}</span><h1>${game.title}</h1></div><button class="secondary-button compact" data-change-connection>${icon('refresh', 14)} Trocar live</button></div>${gameHud(game, session)}${gameArena(game, session)}<div class="game-events-strip"><span class="eyebrow">ÚLTIMO SINAL</span><span id="game-last-event">${state.lastEvents[0]?.text || 'Aguardando o próximo evento da audiência...'}</span><span class="strip-live"><span></span> LIVE</span></div>` : `<div class="game-connect-screen"><div class="game-connect-visual"><div class="connect-orbit"></div><div class="connect-core">${icon(game.icon, 32)}</div></div><span class="eyebrow">ANTES DE JOGAR</span><h1>Conecte a live<br/><em>para abrir a arena.</em></h1><p>Informe o username de uma live pública do TikTok e comece a receber eventos reais.</p><form class="connect-form game-connect-form" data-form="connect"><span class="connect-at">@</span><input name="username" value="${escapeHtml(state.connection.username || state.user?.tiktokUsername || '')}" placeholder="username do TikTok" required /><button class="primary-button" type="submit">Começar monitoramento ${icon('arrow-right', 16)}</button></form><div class="hero-note"><span class="secure-dot">${icon('check', 11)}</span> conexão real · sem eventos inventados</div></div>`}</main><div class="landscape-hint"><span>${icon('monitor', 21)}</span><p>Vire o celular na horizontal<br/><small>para aproveitar a arena completa</small></p></div></div>`;
}

function render() {
  finishRoundIfNeeded();
  state.user = getCurrentUser();
  const currentRoute = route();
  if (!state.user && !['/login', '/register', '/'].includes(currentRoute)) navigate('/login');
  if (currentRoute === '/' || currentRoute === '/login') app.innerHTML = authView('login');
  else if (currentRoute === '/register') app.innerHTML = authView('register');
  else if (currentRoute === '/profile') app.innerHTML = profileView();
  else if (currentRoute === '/activity') app.innerHTML = activityView();
  else if (currentRoute.startsWith('/game/')) app.innerHTML = gameView(currentRoute.split('/')[2]);
  else app.innerHTML = dashboardView();
  bindEvents();
}

function connectToLive(username) {
  const clean = username.replace(/^@/, '').trim();
  if (!clean) return;
  state.connection.username = clean;
  state.connection.live = false;
  connector.connect(clean);
  showToast(`Conectando à live pública @${clean}...`);
  render();
}

function updateLiveWidgets(detail) {
  state.connection.stats = detail.stats;
  document.querySelectorAll('[data-stat="likes"]').forEach((node) => { node.textContent = formatNumber(detail.stats.likes); });
  document.querySelectorAll('[data-stat="gifts"]').forEach((node) => { node.textContent = formatNumber(detail.stats.gifts); });
  document.querySelectorAll('[data-stat="comments"]').forEach((node) => { node.textContent = formatNumber(detail.stats.comments); });
  document.querySelectorAll('[data-stat="followers"]').forEach((node) => { node.textContent = formatNumber(detail.stats.followers); });
  const feed = document.querySelector('#live-feed');
  if (feed) feed.innerHTML = state.lastEvents.slice(0, 5).map(eventRow).join('');
  const lastEvent = document.querySelector('#game-last-event');
  if (lastEvent && detail.event) lastEvent.textContent = detail.event.text;
  const eventCount = document.querySelector('[data-game-events]');
  if (eventCount) eventCount.textContent = String(state.lastEvents.length);
}

function handleGameAction(action) {
  const game = games.find((candidate) => candidate.id === state.gameSession?.id);
  if (!game) return;
  if (action === 'like') {
    state.gameSession.score += 250 * state.gameSession.combo;
    state.gameSession.combo = Math.min(9, state.gameSession.combo + 1);
    showToast(`Combo ${state.gameSession.combo}x ativado!`, 'success');
    render();
  }
  if (action === 'boost') {
    state.gameSession.progress[0] = Math.min(100, state.gameSession.progress[0] + 8);
    state.gameSession.progress[1] = Math.min(100, state.gameSession.progress[1] + 4);
    state.gameSession.score += 120;
    showToast('A corrida ganhou velocidade.', 'success');
    render();
  }
}

function bindEvents() {
  const openGameCard = (event) => {
    event.preventDefault();
    event.stopPropagation();
    const target = event.currentTarget.dataset.gameRoute;
    if (target) navigate(target);
  };
  document.querySelectorAll('.game-card').forEach((card) => {
    card.addEventListener('click', openGameCard);
    card.addEventListener('touchend', openGameCard, { passive: false });
  });
  document.querySelectorAll('[data-toggle-password]').forEach((button) => button.addEventListener('click', () => {
    const input = button.parentElement.querySelector('input');
    input.type = input.type === 'password' ? 'text' : 'password';
    button.innerHTML = icon(input.type === 'password' ? 'eye' : 'eye', 17);
  }));
  document.querySelectorAll('[data-demo-login]').forEach((button) => button.addEventListener('click', () => { demoLogin(); state.user = getCurrentUser(); navigate('/app'); showToast('Conta demo aberta. Informe uma live pública para conectar.'); }));
  document.querySelectorAll('[data-form="login"]').forEach((form) => form.addEventListener('submit', (event) => { event.preventDefault(); const result = login(form.email.value, form.password.value); if (!result.ok) return showToast(result.error, 'error'); state.user = result.user; navigate('/app'); showToast('Login realizado. Bom jogo!', 'success'); }));
  document.querySelectorAll('[data-form="register"]').forEach((form) => form.addEventListener('submit', (event) => { event.preventDefault(); const result = register({ name: form.name.value, email: form.email.value, password: form.password.value }); if (!result.ok) return showToast(result.error, 'error'); state.user = result.user; navigate('/app'); showToast('Conta criada. Vamos conectar sua live!', 'success'); }));
  document.querySelectorAll('[data-form="connect"]').forEach((form) => form.addEventListener('submit', (event) => { event.preventDefault(); connectToLive(form.username.value); }));
  document.querySelectorAll('[data-form="profile"]').forEach((form) => form.addEventListener('submit', (event) => { event.preventDefault(); const user = updateUser({ name: form.name.value.trim(), tiktokUsername: form.tiktokUsername.value.replace(/^@/, '').trim(), bio: form.bio.value.trim() }); state.user = user; if (user.tiktokUsername) state.connection.username = user.tiktokUsername; showToast('Perfil atualizado.', 'success'); render(); }));
  document.querySelectorAll('[data-logout]').forEach((button) => button.addEventListener('click', () => { connector.disconnect(); state.connection.live = false; logout(); state.user = null; state.lastEvents = []; navigate('/login'); showToast('Você saiu da conta.'); }));
  document.querySelectorAll('[data-fullscreen]').forEach((button) => button.addEventListener('click', async () => { document.body.classList.toggle('is-landscape'); try { if (!document.fullscreenElement) await document.documentElement.requestFullscreen?.(); else await document.exitFullscreen?.(); } catch { /* fullscreen can be unavailable in embedded preview */ } }));
  document.querySelectorAll('[data-change-connection]').forEach((button) => button.addEventListener('click', () => { state.connection.live = false; connector.disconnect(); render(); }));
  document.querySelectorAll('[data-game-action]').forEach((button) => button.addEventListener('click', () => handleGameAction(button.dataset.gameAction)));
  document.querySelectorAll('[data-gift-index]').forEach((button) => button.addEventListener('click', () => { const index = Number(button.dataset.giftIndex); state.gameSession.gifts = state.gameSession.gifts.filter((gift) => gift !== index); state.gameSession.score += (index + 1) * 25; showToast('Gift coletado! +pontuação', 'success'); render(); }));
  document.querySelectorAll('[data-vote]').forEach((button) => button.addEventListener('click', () => { state.gameSession.votes[button.dataset.vote] += 1; state.gameSession.score += 80; showToast('Voto enviado para a live.', 'success'); render(); }));
  document.querySelectorAll('[data-card-index]').forEach((button) => button.addEventListener('click', () => {
    const index = Number(button.dataset.cardIndex);
    if (state.gameSession.revealed.includes(index) || state.gameSession.matched.includes(state.gameSession.cards[index].pair) || state.gameSession.revealed.length >= 2) return;
    state.gameSession.revealed.push(index);
    render();
    if (state.gameSession.revealed.length === 2) {
      const [first, second] = state.gameSession.revealed;
      if (state.gameSession.cards[first].pair === state.gameSession.cards[second].pair) {
        state.gameSession.matched.push(state.gameSession.cards[first].pair);
        state.gameSession.score += 500;
        state.gameSession.revealed = [];
        showToast('Par encontrado. Você está viralizando!', 'success');
        render();
      } else {
        window.setTimeout(() => { state.gameSession.revealed = []; render(); }, 750);
      }
    }
  }));
}

connector.addEventListener('connected', (event) => { state.connection.live = true; state.connection.username = event.detail.username; state.connection.stats = event.detail.stats; state.liveLeaderboard = []; state.gameSession = null; setConnectedUsername(event.detail.username); showToast(`Live @${event.detail.username} conectada. Eventos reais chegando.`, 'success'); render(); });
connector.addEventListener('event', (event) => { state.lastEvents = [event.detail.event, ...state.lastEvents].slice(0, 8); applyBattleSignal(event.detail.event); updateLiveWidgets(event.detail); if (route().startsWith('/game/')) render(); });
connector.addEventListener('disconnected', () => { state.connection.live = false; });
connector.addEventListener('error', (event) => { state.connection.live = false; showToast(event.detail?.message || 'Não foi possível conectar à live.', 'error'); render(); });
window.addEventListener('hashchange', render);
const SHOT_MS = 550;

function updateFighterPositions(dt, now) {
  const session = state.gameSession;
  if (!session) return;
  const speed = 9; // % por segundo
  for (const team of ['girls', 'boys']) {
    for (const f of session[team]) {
      if (now >= f.nextMoveAt) {
        const zone = TEAM_ZONES[team];
        f.tx = randomIn(zone.minX, zone.maxX);
        f.ty = randomIn(16, 84);
        f.nextMoveAt = now + randomIn(1400, 3200);
      }
      if (!f.nextShotAt) f.nextShotAt = now + randomIn(200, 1200);
      if (now >= f.nextShotAt) {
        const enemies = session[team === 'girls' ? 'boys' : 'girls'];
        if (enemies.length) fireShot(team, f, enemies[Math.floor(Math.random() * enemies.length)], now);
        f.nextShotAt = now + randomIn(500, 1100);
      }
      const dx = f.tx - f.x;
      const dy = f.ty - f.y;
      const dist = Math.hypot(dx, dy);
      if (dist > 0.01) {
        const k = Math.min(1, (speed * dt) / dist);
        f.x += dx * k;
        f.y += dy * k;
      }
    }
  }
}

function paintFighters() {
  const session = state.gameSession;
  if (!session) return;
  document.querySelectorAll('[data-fighter-id]').forEach((el) => {
    const f = session[el.dataset.team].find((item) => item.id === el.dataset.fighterId);
    if (!f) { el.remove(); return; }
    el.style.left = `${f.x.toFixed(2)}%`;
    el.style.top = `${f.y.toFixed(2)}%`;
    const hp = Math.max(0, Math.round(f.hp / f.maxHp * 100));
    const bar = el.querySelector('.orb-hp i');
    if (bar) bar.style.width = `${hp}%`;
    const label = el.querySelector('.orb-hp span');
    if (label) label.textContent = `${hp}%`;
  });
}

function paintProjectiles(now) {
  const session = state.gameSession;
  const layer = document.querySelector('.battle-projectiles');
  if (!session || !layer) return;
  for (const s of session.shots) {
    if (!s.hit && now - s.born >= SHOT_MS) { s.hit = true; resolveHit(s); }
  }
  session.shots = session.shots.filter((s) => now - s.born < SHOT_MS);
  const alive = new Set(session.shots.map((s) => `shot-${s.id}`));
  layer.querySelectorAll('.battle-shot').forEach((el) => { if (!alive.has(el.id)) el.remove(); });
  for (const s of session.shots) {
    let el = document.getElementById(`shot-${s.id}`);
    if (!el) {
      el = document.createElement('span');
      el.id = `shot-${s.id}`;
      el.className = `battle-shot ${s.team}`;
      layer.appendChild(el);
    }
    const p = Math.min(1, (now - s.born) / SHOT_MS);
    el.style.left = `${(s.fromX + (s.toX - s.fromX) * p).toFixed(2)}%`;
    el.style.top = `${(s.fromY + (s.toY - s.fromY) * p).toFixed(2)}%`;
    el.style.opacity = p > 0.85 ? String((1 - p) / 0.15) : '1';
  }
}

let lastFrame = performance.now();
function animationFrame(now) {
  const dt = Math.min(0.05, (now - lastFrame) / 1000);
  lastFrame = now;
  if (state.gameSession?.id === 'boys-vs-girls' && route().startsWith('/game/')) {
    updateFighterPositions(dt, now);
    paintFighters();
    paintProjectiles(now);
  }
  requestAnimationFrame(animationFrame);
}
requestAnimationFrame(animationFrame);

window.setInterval(() => {
  if (state.gameSession?.id !== 'boys-vs-girls' || !route().startsWith('/game/')) return;
  const before = state.gameSession.round;
  finishRoundIfNeeded();
  if (state.gameSession.round !== before || state.gameSession.dirty) { state.gameSession.dirty = false; return render(); }
  const clock = document.querySelector('.round-clock');
  if (clock) clock.textContent = clockText(state.gameSession);
}, 1000);

if (state.user && state.connection.username && !state.connection.live) {
  connector.connect(state.connection.username);
  state.connection.live = true;
}
render();
