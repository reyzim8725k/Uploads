const STORE_KEY = 'tikconector_json_v2_real';

const hash = (value) => {
  let result = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    result ^= value.charCodeAt(index);
    result = Math.imul(result, 16777619);
  }
  return (result >>> 0).toString(16);
};

const makeDefaultStore = () => ({
  version: 1,
  currentUserId: null,
  users: [
    {
      id: 'demo-user',
      name: 'Camila Costa',
      email: 'demo@tikconector.app',
      passwordHash: hash('demo123'),
      tiktokUsername: '',
      bio: 'Transformando a live em playground.',
      avatar: '/assets/generated/6jwBs96CA0je1zDl8qXbG4-image-3.webp',
      gamesPlayed: 18,
      bestScore: 8420,
      createdAt: new Date().toISOString()
    }
  ],
  recentGames: ['batalha-likes', 'chuva-gifts'],
  connectedUsername: ''
});

export function getStore() {
  try {
    const saved = localStorage.getItem(STORE_KEY);
    return saved ? { ...makeDefaultStore(), ...JSON.parse(saved) } : makeDefaultStore();
  } catch {
    return makeDefaultStore();
  }
}

export function saveStore(store) {
  localStorage.setItem(STORE_KEY, JSON.stringify(store));
  return store;
}

export function getCurrentUser(store = getStore()) {
  return store.users.find((user) => user.id === store.currentUserId) || null;
}

export function login(email, password) {
  const store = getStore();
  const user = store.users.find((candidate) => candidate.email.toLowerCase() === email.trim().toLowerCase());
  if (!user || user.passwordHash !== hash(password)) return { ok: false, error: 'E-mail ou senha não conferem.' };
  store.currentUserId = user.id;
  saveStore(store);
  return { ok: true, user };
}

export function demoLogin() {
  const store = getStore();
  store.currentUserId = 'demo-user';
  saveStore(store);
  return getCurrentUser(store);
}

export function register({ name, email, password }) {
  const store = getStore();
  if (store.users.some((user) => user.email.toLowerCase() === email.trim().toLowerCase())) {
    return { ok: false, error: 'Este e-mail já está cadastrado.' };
  }
  const user = {
    id: `user-${Date.now()}`,
    name: name.trim(),
    email: email.trim().toLowerCase(),
    passwordHash: hash(password),
    tiktokUsername: '',
    bio: 'Novo creator no Tik Conector.',
    avatar: '/assets/generated/6jwBs96CA0je1zDl8qXbG4-image-3.webp',
    gamesPlayed: 0,
    bestScore: 0,
    createdAt: new Date().toISOString()
  };
  store.users.push(user);
  store.currentUserId = user.id;
  saveStore(store);
  return { ok: true, user };
}

export function logout() {
  const store = getStore();
  store.currentUserId = null;
  saveStore(store);
}

export function updateUser(updates) {
  const store = getStore();
  const index = store.users.findIndex((user) => user.id === store.currentUserId);
  if (index === -1) return null;
  store.users[index] = { ...store.users[index], ...updates };
  saveStore(store);
  return store.users[index];
}

export function setConnectedUsername(username) {
  const store = getStore();
  store.connectedUsername = username;
  updateUser({ tiktokUsername: username });
  saveStore(store);
  return store;
}

export function addRecentGame(gameId, score = 0) {
  const store = getStore();
  store.recentGames = [gameId, ...store.recentGames.filter((id) => id !== gameId)].slice(0, 4);
  const user = getCurrentUser(store);
  if (user) {
    user.gamesPlayed = (user.gamesPlayed || 0) + 1;
    user.bestScore = Math.max(user.bestScore || 0, score);
  }
  saveStore(store);
}
