export class TikTokLiveConnector extends EventTarget {
  constructor() {
    super();
    this.username = '';
    this.source = null;
    this.connected = false;
  }

  connect(username) {
    this.disconnect(false);
    this.username = String(username || '').replace(/^@/, '').trim();
    if (!this.username) return false;
    this.source = new EventSource('/api/live/events');
    this.source.addEventListener('connected', (event) => {
      const detail = JSON.parse(event.data);
      this.connected = true;
      this.dispatchEvent(new CustomEvent('connected', { detail }));
    });
    this.source.addEventListener('state', (event) => {
      const detail = JSON.parse(event.data);
      if (detail.live) {
        this.connected = true;
        this.dispatchEvent(new CustomEvent('connected', { detail }));
      }
      if (detail.lastEvent) this.dispatchEvent(new CustomEvent('event', { detail: { event: detail.lastEvent, stats: detail.stats } }));
    });
    this.source.addEventListener('event', (event) => {
      this.dispatchEvent(new CustomEvent('event', { detail: JSON.parse(event.data) }));
    });
    this.source.addEventListener('disconnected', () => {
      this.connected = false;
      this.dispatchEvent(new CustomEvent('disconnected'));
    });
    this.source.addEventListener('error', (event) => {
      let detail = { message: 'Não foi possível conectar à live.' };
      try { detail = JSON.parse(event.data); } catch { /* browser connection error */ }
      this.dispatchEvent(new CustomEvent('error', { detail }));
    });
    fetch('/api/live/connect', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: this.username }) })
      .then(async (response) => {
        if (!response.ok) {
          const body = await response.json().catch(() => ({}));
          throw new Error(body.error || 'Não foi possível conectar à live.');
        }
      })
      .catch((error) => this.dispatchEvent(new CustomEvent('error', { detail: { message: error.message } })));
    return true;
  }

  disconnect(notify = true) {
    if (this.source) this.source.close();
    this.source = null;
    if (notify && this.connected) fetch('/api/live/disconnect', { method: 'POST' }).catch(() => {});
    this.connected = false;
  }
}
