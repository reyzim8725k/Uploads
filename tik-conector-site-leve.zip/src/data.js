export const brand = {
  name: 'Tik Conector', eyebrow: 'LIVE PLAYGROUND', accent: '#21F4D5', magenta: '#FF2D7A',
  logo: '/assets/site/logo-mark.svg', cover: '/assets/boys-girls/capa.webp',
  portal: '/assets/site/auth-portal.webp',
  signals: '/assets/site/auth-signals.webp',
  avatar: '/assets/generated/6jwBs96CA0je1zDl8qXbG4-image-3.webp'
};

export const boysGirlsVisuals = {
  cover: '/assets/boys-girls/capa.webp', teamBoys: '/assets/boys-girls/team_boys.webp', teamGirls: '/assets/boys-girls/team_girls.webp',
  vs: '/assets/boys-girls/emblema_vs.webp', background: '/assets/boys-girls/arena.webp',
  boysAttack: '/assets/boys-girls/ataque_boys.webp', boysImpact: '/assets/boys-girls/impacto_boys.webp', boysShield: '/assets/boys-girls/escudo_boys.webp',
  boysBoost: '/assets/boys-girls/boost_boys.webp', boysMedal: '/assets/boys-girls/medal_boys.webp', girlsAttack: '/assets/boys-girls/team_girls.webp',
  girlsImpact: '/assets/boys-girls/team_girls.webp', girlsShield: '/assets/boys-girls/team_girls.webp', girlsBoost: '/assets/boys-girls/team_girls.webp',
  girlsMedal: '/assets/boys-girls/team_girls.webp', girlsChibi: '/assets/boys-girls/team_girls.webp', boysChibi: '/assets/boys-girls/team_boys.webp',
  ball: '/assets/boys-girls/emblema_vs.webp', divider: '/assets/boys-girls/emblema_vs.webp', verticalBackground: '/assets/boys-girls/arena.webp', landscapeBackground: '/assets/boys-girls/arena.webp',
  teamLeft: '/assets/boys-girls/team_girls.webp', teamRight: '/assets/boys-girls/team_boys.webp'
};

export const jesusDiaboVisuals = {
  cover: '/assets/jesus-diabo-premium/capa-premium.webp', teamJesus: '/assets/jesus-diabo-premium/jesus-premium-transparent.webp', teamDiabo: '/assets/jesus-diabo-premium/diabo-premium-transparent.webp',
  vs: '/assets/jesus-diabo-premium/vs-premium-transparent.webp', background: '/assets/jesus-diabo-premium/arena-duel-premium.webp',
  jesusAttack: '/assets/jesus-diabo-premium/holy-bolt-premium-transparent.webp', diaboAttack: '/assets/jesus-diabo-premium/infernal-bolt-premium-transparent.webp', leftAttack: '/assets/jesus-diabo-premium/holy-bolt-premium-transparent.webp', rightAttack: '/assets/jesus-diabo-premium/infernal-bolt-premium-transparent.webp',
  jesusImpact: '/assets/jesus-diabo-premium/holy-bolt-premium-transparent.webp', diaboImpact: '/assets/jesus-diabo-premium/infernal-bolt-premium-transparent.webp',
  giftCrown: '/assets/jesus-diabo-premium/gift-relic-premium-transparent.webp', ball: '/assets/jesus-diabo-premium/vs-premium-transparent.webp', divider: '/assets/jesus-diabo-premium/vs-premium-transparent.webp',
  verticalBackground: '/assets/jesus-diabo-premium/arena-duel-premium.webp', landscapeBackground: '/assets/jesus-diabo-premium/arena-landscape-premium.webp',
  teamLeft: '/assets/jesus-diabo-premium/jesus-premium-transparent.webp', teamRight: '/assets/jesus-diabo-premium/diabo-premium-transparent.webp'
};

const rivalryVisuals = (slug, sideLeft, sideRight, ext = 'png') => ({
  cover: `/assets/rivalry-games/${slug}/capa-v3.${ext}`, background: `/assets/rivalry-games/${slug}/arena-v3.${ext}`, verticalBackground: `/assets/rivalry-games/${slug}/arena-v3.${ext}`, landscapeBackground: `/assets/rivalry-games/${slug}/arena-v3.${ext}`,
  teamLeft: `/assets/rivalry-games/${slug}/left-v3.${ext}`, teamRight: `/assets/rivalry-games/${slug}/right-v3.${ext}`, vs: `/assets/rivalry-games/${slug}/vs-v3.${ext}`, ball: `/assets/rivalry-games/${slug}/vs-v3.${ext}`, divider: `/assets/rivalry-games/${slug}/vs-v3.${ext}`,
  teamJesus: sideLeft, teamDiabo: sideRight, teamGirls: `/assets/rivalry-games/${slug}/left-v3.${ext}`, teamBoys: `/assets/rivalry-games/${slug}/right-v3.${ext}`,
  leftAttack: `/assets/rivalry-games/${slug}/ataque-left.svg?v=3`, rightAttack: `/assets/rivalry-games/${slug}/ataque-right.svg?v=3`, leftImpact: `/assets/rivalry-games/${slug}/impact-left.svg?v=3`, rightImpact: `/assets/rivalry-games/${slug}/impact-right.svg?v=3`, shield: `/assets/rivalry-games/${slug}/escudo.svg?v=3`, boost: `/assets/rivalry-games/${slug}/boost.svg?v=3`, medal: `/assets/rivalry-games/${slug}/medalha.svg?v=3`, gift: `/assets/rivalry-games/${slug}/gift.svg?v=3`
});

export const battleThemes = {
  'boys-vs-girls': { left: 'girls', right: 'boys', leftName: 'GIRLS', rightName: 'BOYS', leftCommand: 'GIRL', rightCommand: 'BOY', visuals: boysGirlsVisuals },
  'jesus-vs-diabo': { left: 'girls', right: 'boys', leftName: 'JESUS', rightName: 'DIABO', leftCommand: 'JESUS', rightCommand: 'DIABO', visuals: jesusDiaboVisuals },
  'fogo-vs-gelo': { left: 'girls', right: 'boys', leftName: 'FOGO', rightName: 'GELO', leftCommand: 'FOGO', rightCommand: 'GELO', visuals: rivalryVisuals('fogo-gelo', 'FOGO', 'GELO') },
  'herois-vs-viloes': { left: 'girls', right: 'boys', leftName: 'HERÓIS', rightName: 'VILÕES', leftCommand: 'HEROI', rightCommand: 'VILAO', visuals: rivalryVisuals('herois-viloes', 'HERÓIS', 'VILÕES', 'svg') },
  'humanos-vs-robos': { left: 'girls', right: 'boys', leftName: 'HUMANOS', rightName: 'ROBÔS', leftCommand: 'HUMANO', rightCommand: 'ROBO', visuals: rivalryVisuals('humanos-vs-robos', 'HUMANOS', 'ROBÔS', 'svg') },
  'dragoes-vs-guerreiros': { left: 'girls', right: 'boys', leftName: 'DRAGÕES', rightName: 'GUERREIROS', leftCommand: 'DRAGAO', rightCommand: 'GUERREIRO', visuals: rivalryVisuals('dragoes-vs-guerreiros', 'DRAGÕES', 'GUERREIROS', 'svg') }
};

export const games = [
  { id: 'boys-vs-girls', number: '01', title: 'Boys vs Girls', short: 'A batalha da live.', description: 'Comente BOY ou GIRL, entre na sua equipe e ajude seu time a chegar aos 100 pontos.', label: 'TEAM BATTLE', metric: 'battle', accent: '#21F4D5', gradient: 'linear-gradient(135deg, #102f49 0%, #161629 52%, #3b1639 100%)', icon: 'swords', assets: [], visuals: boysGirlsVisuals },
  { id: 'jesus-vs-diabo', number: '02', title: 'Jesus vs Diabo', short: 'A batalha celestial da live.', description: 'Comente JESUS ou DIABO, escolha seu lado e leve sua legião aos 100 pontos.', label: 'CELESTIAL BATTLE', metric: 'battle', accent: '#FFD166', gradient: 'linear-gradient(135deg, #123D63 0%, #17152C 50%, #55163D 100%)', icon: 'sparkles', assets: [], visuals: jesusDiaboVisuals },
  { id: 'fogo-vs-gelo', number: '03', title: 'Fogo vs Gelo', short: 'Calor contra congelamento.', description: 'Comente FOGO ou GELO e faça seu elemento dominar a arena.', label: 'ELEMENTAL RIVALRY', metric: 'battle', accent: '#FF7A3D', gradient: 'linear-gradient(135deg, #6E2214 0%, #17172D 50%, #145B7A 100%)', icon: 'bolt', assets: [], visuals: rivalryVisuals('fogo-gelo', 'FOGO', 'GELO') },
  { id: 'herois-vs-viloes', number: '04', title: 'Heróis vs Vilões', short: 'A justiça contra o caos.', description: 'Comente HEROI ou VILAO e escolha o destino da cidade.', label: 'HEROIC SHOWDOWN', metric: 'battle', accent: '#6DD6FF', gradient: 'linear-gradient(135deg, #123A6B 0%, #161627 50%, #491B68 100%)', icon: 'trophy', assets: [], visuals: rivalryVisuals('herois-viloes', 'HERÓIS', 'VILÕES', 'svg') },
  { id: 'humanos-vs-robos', number: '05', title: 'Humanos vs Robôs', short: 'Instinto contra inteligência.', description: 'Comente HUMANO ou ROBO e lidere sua espécie à vitória.', label: 'FUTURE WAR', metric: 'battle', accent: '#FFC857', gradient: 'linear-gradient(135deg, #49331A 0%, #131A26 50%, #223B52 100%)', icon: 'monitor', assets: [], visuals: rivalryVisuals('humanos-vs-robos', 'HUMANOS', 'ROBÔS', 'svg') },
  { id: 'dragoes-vs-guerreiros', number: '06', title: 'Dragões vs Guerreiros', short: 'Lendas contra aço.', description: 'Comente DRAGAO ou GUERREIRO e conquiste o campo de batalha.', label: 'MYTHIC CLASH', metric: 'battle', accent: '#6DFFB3', gradient: 'linear-gradient(135deg, #113E37 0%, #171827 50%, #54201D 100%)', icon: 'sparkles', assets: [], visuals: rivalryVisuals('dragoes-vs-guerreiros', 'DRAGÕES', 'GUERREIROS', 'svg') }
];

export const navItems = [
  { id: 'app', label: 'Jogo', icon: 'grid' },
  { id: 'activity', label: 'Atividade', icon: 'pulse' },
  { id: 'profile', label: 'Perfil', icon: 'user' }
];
